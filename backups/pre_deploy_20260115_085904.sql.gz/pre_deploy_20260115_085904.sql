--
-- PostgreSQL database dump
--

\restrict gHai3FrszREZCJthxdB8v7hblEIBkj3409QKG24yXYQaXwVZWMBgC3IT6LzSaID

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: skillfade_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO skillfade_user;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: skillfade_user
--

CREATE TABLE public.categories (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.categories OWNER TO skillfade_user;

--
-- Name: event_templates; Type: TABLE; Schema: public; Owner: skillfade_user
--

CREATE TABLE public.event_templates (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    event_type character varying(20) NOT NULL,
    type character varying(50) NOT NULL,
    default_duration_minutes integer,
    default_notes text,
    created_at timestamp without time zone
);


ALTER TABLE public.event_templates OWNER TO skillfade_user;

--
-- Name: learning_events; Type: TABLE; Schema: public; Owner: skillfade_user
--

CREATE TABLE public.learning_events (
    id uuid NOT NULL,
    skill_id uuid NOT NULL,
    user_id uuid NOT NULL,
    date date NOT NULL,
    type character varying(50) NOT NULL,
    notes text,
    duration_minutes integer,
    created_at timestamp without time zone
);


ALTER TABLE public.learning_events OWNER TO skillfade_user;

--
-- Name: practice_events; Type: TABLE; Schema: public; Owner: skillfade_user
--

CREATE TABLE public.practice_events (
    id uuid NOT NULL,
    skill_id uuid NOT NULL,
    user_id uuid NOT NULL,
    date date NOT NULL,
    type character varying(50) NOT NULL,
    notes text,
    duration_minutes integer,
    created_at timestamp without time zone
);


ALTER TABLE public.practice_events OWNER TO skillfade_user;

--
-- Name: skill_dependencies; Type: TABLE; Schema: public; Owner: skillfade_user
--

CREATE TABLE public.skill_dependencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    skill_id uuid NOT NULL,
    depends_on_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.skill_dependencies OWNER TO skillfade_user;

--
-- Name: skills; Type: TABLE; Schema: public; Owner: skillfade_user
--

CREATE TABLE public.skills (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    created_at timestamp without time zone,
    archived_at timestamp without time zone,
    decay_rate double precision DEFAULT '0.02'::double precision NOT NULL,
    target_freshness double precision,
    notes text,
    category_id uuid
);


ALTER TABLE public.skills OWNER TO skillfade_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: skillfade_user
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    settings json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    is_admin boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO skillfade_user;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: skillfade_user
--

COPY public.alembic_version (version_num) FROM stdin;
006
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: skillfade_user
--

COPY public.categories (id, user_id, name, created_at) FROM stdin;
6707d03f-3adf-4220-956e-569ad3695f2b	6891895a-6e91-4a61-8de6-4388207c5635	Trading	2026-01-14 10:47:15.970503
d92b95fa-9b51-4f8c-80e0-8e9b2968966c	87d5cb2c-be5a-44b1-a085-d44c37e7b82c	asd	2026-01-15 08:05:38.273655
8dc0c59a-733b-4efc-b5fe-c3d1d9abbd9f	5539c045-f670-42b3-a637-354dd96aa064	Programming	2026-01-15 08:57:22.108974
\.


--
-- Data for Name: event_templates; Type: TABLE DATA; Schema: public; Owner: skillfade_user
--

COPY public.event_templates (id, user_id, name, event_type, type, default_duration_minutes, default_notes, created_at) FROM stdin;
f4c60b9b-498d-46b0-8344-2650d2369242	87d5cb2c-be5a-44b1-a085-d44c37e7b82c	,	practice	project	\N	\N	2026-01-15 08:07:07.734393
\.


--
-- Data for Name: learning_events; Type: TABLE DATA; Schema: public; Owner: skillfade_user
--

COPY public.learning_events (id, skill_id, user_id, date, type, notes, duration_minutes, created_at) FROM stdin;
70d5ede0-aa81-49d4-a1f9-e9d97daeecc9	3febc62b-af67-4b04-9b8e-b2cde408a517	87d5cb2c-be5a-44b1-a085-d44c37e7b82c	2026-01-15	video	\N	\N	2026-01-15 08:06:01.547767
\.


--
-- Data for Name: practice_events; Type: TABLE DATA; Schema: public; Owner: skillfade_user
--

COPY public.practice_events (id, skill_id, user_id, date, type, notes, duration_minutes, created_at) FROM stdin;
9612d55a-295b-413d-9049-70cf3f92cf88	3febc62b-af67-4b04-9b8e-b2cde408a517	87d5cb2c-be5a-44b1-a085-d44c37e7b82c	2026-01-15	writing	\N	\N	2026-01-15 08:06:07.023812
\.


--
-- Data for Name: skill_dependencies; Type: TABLE DATA; Schema: public; Owner: skillfade_user
--

COPY public.skill_dependencies (id, skill_id, depends_on_id, created_at) FROM stdin;
\.


--
-- Data for Name: skills; Type: TABLE DATA; Schema: public; Owner: skillfade_user
--

COPY public.skills (id, user_id, name, created_at, archived_at, decay_rate, target_freshness, notes, category_id) FROM stdin;
7d34d90d-dc03-4137-ae63-1ca73dd86220	6891895a-6e91-4a61-8de6-4388207c5635	OrderFlow	2026-01-14 10:47:15.972173	\N	0.02	\N	\N	6707d03f-3adf-4220-956e-569ad3695f2b
3febc62b-af67-4b04-9b8e-b2cde408a517	87d5cb2c-be5a-44b1-a085-d44c37e7b82c	asd	2026-01-15 08:05:38.275518	\N	0.02	\N	\N	d92b95fa-9b51-4f8c-80e0-8e9b2968966c
74378489-e997-4be7-8a7c-c075b6477f73	5539c045-f670-42b3-a637-354dd96aa064	Django	2026-01-15 08:57:22.109662	\N	0.02	\N	\N	8dc0c59a-733b-4efc-b5fe-c3d1d9abbd9f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: skillfade_user
--

COPY public.users (id, email, password_hash, settings, created_at, updated_at, is_admin) FROM stdin;
6891895a-6e91-4a61-8de6-4388207c5635	ruhid.ibadli@gmail.com	$2b$12$dz5RZVuX.Ym6VZJXvjtViOxLp1p5QiADTETMcFQMP.T.rINdv8JOK	{}	2026-01-14 10:42:07.117646	2026-01-14 10:46:22.88013	t
87d5cb2c-be5a-44b1-a085-d44c37e7b82c	asd@asd.asd	$2b$12$nw1S0QKHPn6qL1XJCt3NoOUyDMNuY6S5HVf0gOX5tiCTbaUJg7Zh6	{}	2026-01-15 08:05:18.844053	2026-01-15 08:05:18.844056	f
4963bf5d-f22d-4992-8406-a755e9522da8	saadchraibi85@gmail.com	$2b$12$Y8sOjeO9tF6SFwAGDFcDwepRCFort8Y2zBKsCD/wkm4Bhkt2TX.S2	{}	2026-01-15 08:43:49.685394	2026-01-15 08:43:49.685397	f
5539c045-f670-42b3-a637-354dd96aa064	zulfuqar.ismayilzada@gmail.com	$2b$12$rJQuGLDDe7tUnFumwH86oeJjyuc4OHvtTKoETvJSLmCecFii7ERkS	{}	2026-01-15 08:56:57.575736	2026-01-15 08:56:57.575739	f
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: event_templates event_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.event_templates
    ADD CONSTRAINT event_templates_pkey PRIMARY KEY (id);


--
-- Name: learning_events learning_events_pkey; Type: CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.learning_events
    ADD CONSTRAINT learning_events_pkey PRIMARY KEY (id);


--
-- Name: practice_events practice_events_pkey; Type: CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.practice_events
    ADD CONSTRAINT practice_events_pkey PRIMARY KEY (id);


--
-- Name: skill_dependencies skill_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.skill_dependencies
    ADD CONSTRAINT skill_dependencies_pkey PRIMARY KEY (id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (id);


--
-- Name: skill_dependencies uq_skill_dependency; Type: CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.skill_dependencies
    ADD CONSTRAINT uq_skill_dependency UNIQUE (skill_id, depends_on_id);


--
-- Name: categories uq_user_category_name; Type: CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT uq_user_category_name UNIQUE (user_id, name);


--
-- Name: skills uq_user_skill_name; Type: CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT uq_user_skill_name UNIQUE (user_id, name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_learning_events_skill; Type: INDEX; Schema: public; Owner: skillfade_user
--

CREATE INDEX idx_learning_events_skill ON public.learning_events USING btree (skill_id, date);


--
-- Name: idx_practice_events_skill; Type: INDEX; Schema: public; Owner: skillfade_user
--

CREATE INDEX idx_practice_events_skill ON public.practice_events USING btree (skill_id, date);


--
-- Name: ix_categories_user_id; Type: INDEX; Schema: public; Owner: skillfade_user
--

CREATE INDEX ix_categories_user_id ON public.categories USING btree (user_id);


--
-- Name: ix_skill_dependencies_depends_on_id; Type: INDEX; Schema: public; Owner: skillfade_user
--

CREATE INDEX ix_skill_dependencies_depends_on_id ON public.skill_dependencies USING btree (depends_on_id);


--
-- Name: ix_skill_dependencies_skill_id; Type: INDEX; Schema: public; Owner: skillfade_user
--

CREATE INDEX ix_skill_dependencies_skill_id ON public.skill_dependencies USING btree (skill_id);


--
-- Name: ix_skills_category_id; Type: INDEX; Schema: public; Owner: skillfade_user
--

CREATE INDEX ix_skills_category_id ON public.skills USING btree (category_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: skillfade_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: categories categories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: event_templates event_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.event_templates
    ADD CONSTRAINT event_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: skills fk_skills_category_id; Type: FK CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT fk_skills_category_id FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: learning_events learning_events_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.learning_events
    ADD CONSTRAINT learning_events_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES public.skills(id) ON DELETE CASCADE;


--
-- Name: learning_events learning_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.learning_events
    ADD CONSTRAINT learning_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: practice_events practice_events_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.practice_events
    ADD CONSTRAINT practice_events_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES public.skills(id) ON DELETE CASCADE;


--
-- Name: practice_events practice_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.practice_events
    ADD CONSTRAINT practice_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: skill_dependencies skill_dependencies_depends_on_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.skill_dependencies
    ADD CONSTRAINT skill_dependencies_depends_on_id_fkey FOREIGN KEY (depends_on_id) REFERENCES public.skills(id) ON DELETE CASCADE;


--
-- Name: skill_dependencies skill_dependencies_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.skill_dependencies
    ADD CONSTRAINT skill_dependencies_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES public.skills(id) ON DELETE CASCADE;


--
-- Name: skills skills_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: skillfade_user
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict gHai3FrszREZCJthxdB8v7hblEIBkj3409QKG24yXYQaXwVZWMBgC3IT6LzSaID

